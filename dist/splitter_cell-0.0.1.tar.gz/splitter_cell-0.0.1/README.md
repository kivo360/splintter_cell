# Splitter Cell

CLI tool to split files and stuff.